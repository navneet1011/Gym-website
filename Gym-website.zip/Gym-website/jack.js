
function getRandom(){
    let randi= Math.floor(Math.random()*13)+1
    if(randi === 1) return 11;
    else if(randi >= 11) return 10;
    else return randi
}

let cards=[]
let sum = 0
let isstart=false
let message=document.getElementById("opmsg")

function startgame(){
    isstart=true
    document.querySelector('#newbtn').disabled=false
let x=getRandom()
let y=getRandom()
cards.push(x)
cards.push(y)
 sum = x + y
    document.getElementById("crd").textContent="Cards:"+ " "+x +"  "+y+" "
document.getElementById("total").innerText = "Sum:"+ " "+sum
let message=document.getElementById("opmsg")
rendergame()
}

function rendergame() {
    if(sum<21)
    message.textContent="Do you Want To Draw a Card Again"
    else if(sum === 21){
    message.textContent="YOU WON The Game"
    document.querySelector('#newbtn').disabled=true}
    else{
    message.textContent="Afsos Aap Game Se Bahar Hue \n Start a new Game"
    document.querySelector('#newbtn').disabled=true }
}

function newcard(){
    if(isstart){
 var newcd = getRandom()
 cards.push(newcd)
 sum+=newcd;
 document.getElementById("crd").innerText = document.getElementById("crd").innerText+"  "+newcd
 document.getElementById("total").innerText = "Sum:"+" "+sum
 rendergame();
    }
}


let sent =["nikal bsdk","chala ja bsdk","idhar kyu aya h","khi aur mara"]
let msg = document.getElementById("greet")
for(let i=0;i<sent.length;i++){
    msg.innerText+=" "+sent[i]
}

