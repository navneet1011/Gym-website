let mobNo = 98526478

let count =0
function increment(){
    count=count+1;
    console.log(count)
    document.getElementById("head6").innerText = count 
}
function save(){
    document.getElementById("prev").innerText = document.getElementById("prev").innerText + " - " + count
    count=0
    document.getElementById("head6").innerText = 0 

}

let welcome = document.getElementById("welcome")

let name="adarsh"
let greeting="welcome back"
welcome.innerText = name + " "+ greeting + "🎶🎶"


